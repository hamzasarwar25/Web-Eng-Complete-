import React from 'react';
import { render } from 'react-dom';
import Shell from './Shell';

render(<Shell />, document.getElementById('root'));
