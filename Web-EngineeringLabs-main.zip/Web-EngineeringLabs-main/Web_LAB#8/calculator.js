function calculator(op1, op2, operator) {
    var result = operator(op1, op2);
    console.log(result);
    return result;
  }