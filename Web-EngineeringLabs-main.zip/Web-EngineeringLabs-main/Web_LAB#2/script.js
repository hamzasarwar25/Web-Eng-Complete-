function Ok(){
    alert("Ok is Clicked")
}
function Cancel(){
    alert("Cancel is Clicked")
}
function login(){
    alert("show message in an alert as Logged in successfully ")
}
