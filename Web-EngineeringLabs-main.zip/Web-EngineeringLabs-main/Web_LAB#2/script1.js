function Ok(){
    alert("Ok is Clicked")
}
function Cancel(){
    alert("Cancel is Clicked")
}
