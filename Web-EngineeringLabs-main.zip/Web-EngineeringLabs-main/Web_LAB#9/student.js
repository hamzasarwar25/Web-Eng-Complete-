const students = {
    getStudents: function() {
      return ['John', 'Jane', 'Jack'];
    }
  };
  
  module.exports = students;
  