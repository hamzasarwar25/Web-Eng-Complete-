const events = {
    getEvents: function() {
      return ['Career Fair', 'Open House', 'Graduation'];
    }
  };
  
  module.exports = events;
  