const faculties = {
    getFaculties: function() {
      return ['Physics', 'Computer Science', 'Biology'];
    }
  };
  
  module.exports = faculties;
  